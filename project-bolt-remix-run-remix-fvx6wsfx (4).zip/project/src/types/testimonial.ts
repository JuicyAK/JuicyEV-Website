export interface Testimonial {
  name: string;
  avatar: string;
  quote: string;
}